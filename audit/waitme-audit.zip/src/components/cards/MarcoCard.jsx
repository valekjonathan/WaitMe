import React from 'react';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, MessageCircle, Phone, PhoneOff } from 'lucide-react';
import { getCarFill, formatPlate } from '@/utils/carUtils';

function MarcoCard({
  photoUrl,
  name,
  carLabel,
  plate,
  carColor,
  onChat,
  statusText = 'COMPLETADA',
  address,
  timeLine,
  priceChip: _priceChip,
  phoneEnabled = false,
  onCall,
  statusEnabled = false,
  bright = false,
  dimmed = false,
  conversationId: _conversationId,
  role: _role,
}) {
  const stUpper = String(statusText || '')
    .trim()
    .toUpperCase();
  const isCountdownLike =
    typeof statusText === 'string' && /^\d{2}:\d{2}(?::\d{2})?$/.test(String(statusText).trim());
  const isCompleted = stUpper === 'COMPLETADA';
  const isDimStatus = stUpper === 'CANCELADA' || stUpper === 'EXPIRADA';
  const statusOn = statusEnabled || isCompleted || isDimStatus || isCountdownLike;

  const photoCls = dimmed
    ? 'w-full h-full object-cover opacity-40 grayscale'
    : 'w-full h-full object-cover';

  const nameCls = dimmed
    ? 'font-bold text-xl text-gray-300 leading-none opacity-70 min-h-[22px]'
    : 'font-bold text-xl text-white leading-none min-h-[22px]';

  const carCls = dimmed
    ? 'text-sm font-medium text-gray-400 leading-none opacity-70 flex-1 flex items-center truncate relative top-[6px]'
    : 'text-sm font-medium text-white leading-none flex-1 flex items-center truncate relative top-[6px]';

  const plateWrapCls = dimmed ? 'opacity-45 flex-shrink-0' : 'flex-shrink-0';
  const carIconWrapCls = dimmed
    ? 'opacity-45 flex-shrink-0 relative -top-[1px]'
    : 'flex-shrink-0 relative -top-[1px]';

  const lineTextCls = dimmed ? 'text-gray-400 leading-5 opacity-80' : 'text-white leading-5';

  const isTimeObj =
    timeLine && typeof timeLine === 'object' && !Array.isArray(timeLine) && 'main' in timeLine;

  const statusBoxCls = statusOn
    ? isCountdownLike
      ? 'border-purple-400/70 bg-purple-600/25'
      : 'border-purple-500/30 bg-purple-600/10'
    : 'border-gray-700 bg-gray-800/60';

  const statusTextCls = statusOn
    ? isCountdownLike
      ? 'text-purple-100'
      : isDimStatus
        ? 'text-gray-400/70'
        : 'text-purple-300'
    : 'text-gray-400 opacity-70';

  const PlateProfile = ({ plate }) => (
    <div className="bg-white rounded-md flex items-center overflow-hidden border-2 border-gray-400 h-7">
      <div className="bg-blue-600 h-full w-5 flex items-center justify-center">
        <span className="text-white text-[8px] font-bold">E</span>
      </div>
      <span className="px-2 text-black font-mono font-bold text-sm tracking-wider">
        {formatPlate(plate)}
      </span>
    </div>
  );

  const CarIconProfile = ({ color, size = 'w-16 h-10' }) => (
    <svg viewBox="0 0 48 24" className={size} fill="none" style={{ transform: 'translateY(3px)' }}>
      <path
        d="M8 16 L10 10 L16 8 L32 8 L38 10 L42 14 L42 18 L8 18 Z"
        fill={color}
        stroke="white"
        strokeWidth="1.5"
      />
      <path
        d="M16 9 L18 12 L30 12 L32 9 Z"
        fill="rgba(255,255,255,0.3)"
        stroke="white"
        strokeWidth="0.5"
      />
      <circle cx="14" cy="18" r="4" fill="#333" stroke="white" strokeWidth="1" />
      <circle cx="14" cy="18" r="2" fill="#666" />
      <circle cx="36" cy="18" r="4" fill="#333" stroke="white" strokeWidth="1" />
      <circle cx="36" cy="18" r="2" fill="#666" />
    </svg>
  );

  return (
    <>
      <div className="flex gap-2.5">
        <div
          className={`w-[95px] h-[85px] rounded-lg overflow-hidden border-2 flex-shrink-0 ${
            dimmed
              ? 'border-gray-600/70 bg-gray-800/30'
              : bright
                ? 'border-purple-500/40 bg-gray-900'
                : 'border-gray-600/70 bg-gray-800/30'
          }`}
        >
          {photoUrl ? (
            <img src={photoUrl} alt={name} className={photoCls} />
          ) : (
            <div
              className={`w-full h-full flex items-center justify-center text-3xl ${
                bright ? 'text-gray-300' : 'text-gray-600 opacity-40'
              }`}
            >
              👤
            </div>
          )}
        </div>

        <div className="flex-1 h-[85px] flex flex-col">
          <p className={nameCls}>{(name || '').split(' ')[0] || 'Usuario'}</p>
          <p className={carCls}>{carLabel || 'Sin datos'}</p>

          <div className="flex items-end gap-2 mt-1 min-h-[28px]">
            <div className={plateWrapCls}>
              <PlateProfile plate={plate} />
            </div>

            <div className="flex-1 flex justify-center">
              <div className={carIconWrapCls}>
                <CarIconProfile color={getCarFill(carColor)} size="w-16 h-10" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-1.5 border-t border-gray-700/80 mt-2">
        <div
          className={
            dimmed ? 'space-y-1.5 opacity-80' : bright ? 'space-y-1.5' : 'space-y-1.5 opacity-80'
          }
        >
          {address ? (
            <div className="flex items-start gap-1.5 text-xs">
              <MapPin
                className={`w-4 h-4 flex-shrink-0 mt-0.5 ${dimmed ? 'text-gray-500' : 'text-purple-400'}`}
              />
              <span className={`${dimmed ? 'text-gray-400' : 'text-white'} leading-5 line-clamp-1`}>
                {address ? `${address}, Oviedo` : 'Calle del Paseo, 25, Oviedo'}
              </span>
            </div>
          ) : null}

          {timeLine ? (
            <div className="flex items-start gap-1.5 text-xs">
              <Clock
                className={`w-4 h-4 flex-shrink-0 mt-0.5 ${dimmed ? 'text-gray-500' : 'text-purple-400'}`}
              />
              {isTimeObj ? (
                <span className={lineTextCls}>
                  <span className="text-white">{timeLine.main}</span>
                  <span className="text-purple-400">{timeLine.accent}</span>
                </span>
              ) : (
                <span className={lineTextCls}>
                  <span className="text-purple-400">{timeLine}</span>
                </span>
              )}
            </div>
          ) : null}
        </div>
      </div>

      <div className="mt-2">
        <div className="flex gap-2">
          <Button
            size="icon"
            className="bg-green-500 hover:bg-green-600 text-white rounded-lg h-8 w-[42px]"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onChat?.();
            }}
          >
            <MessageCircle className="w-4 h-4" />
          </Button>

          {phoneEnabled ? (
            <Button
              size="icon"
              className="bg-white hover:bg-gray-200 text-black rounded-lg h-8 w-[42px]"
              onClick={onCall}
            >
              <Phone className="w-4 h-4" />
            </Button>
          ) : (
            <Button
              variant="outline"
              size="icon"
              className="border-white/30 bg-white/10 text-white rounded-lg h-8 w-[42px] opacity-70 cursor-not-allowed"
              disabled
            >
              <PhoneOff className="w-4 h-4 text-white" />
            </Button>
          )}

          <div className="flex-1">
            <div
              className={`w-full h-8 rounded-lg border-2 flex items-center justify-center px-3 ${statusBoxCls}`}
            >
              <span className={`text-sm font-mono font-extrabold ${statusTextCls}`}>
                {statusText}
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default React.memo(MarcoCard);
