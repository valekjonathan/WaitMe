import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { createPageUrl } from '@/utils';
import * as alerts from '@/data/alerts';
import * as chat from '@/data/chat';
import { useAuth } from '@/lib/AuthContext';
import { useQueryClient } from '@tanstack/react-query';
import * as transactions from '@/data/transactions';
import { Navigation, ChevronDown, ChevronUp, Clock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ParkingMap from '@/components/map/ParkingMap';
import UserAlertCard from '@/components/cards/UserAlertCard';
import { motion, AnimatePresence } from 'framer-motion';
import { finalize, OUTCOME } from '@/lib/transactionEngine';
import { useLocationEngine } from '@/hooks/useLocationEngine';
import { useTransactionMonitoring } from '@/hooks/useTransactionMonitoring';
import { getMetersBetween } from '@/lib/location';
import { getMockNavigateCars } from '@/lib/mockNavigateCars';
import { haversineKm, getCarFill } from '@/utils/carUtils';

function getAlertIdFromLocation() {
  const hash = window.location.hash || '';
  const queryString = hash.indexOf('?') >= 0 ? hash.substring(hash.indexOf('?')) : '';
  const fromHash = new URLSearchParams(queryString).get('alertId');
  if (fromHash) return fromHash;
  return new URLSearchParams(window.location.search).get('alertId');
}

const DEMO_ALERTS = {
  demo_1: {
    id: 'demo_1',
    user_name: 'Sofía',
    user_photo: 'https://randomuser.me/api/portraits/women/44.jpg',
    user_id: 'seller-1',
    user_email: 'seller1@test.com',
    brand: 'SEAT',
    model: 'León',
    color: 'blanco',
    plate: '1234 JKL',
    address: 'Calle Campoamor, 13',
    latitude: 43.3629,
    longitude: -5.8488,
    phone: '600123123',
    allow_phone_calls: true,
    price: 3,
    available_in_minutes: 6,
  },
  demo_2: {
    id: 'demo_2',
    user_name: 'Marco',
    user_photo: 'https://randomuser.me/api/portraits/men/32.jpg',
    user_id: 'seller-2',
    user_email: 'seller2@test.com',
    brand: 'Volkswagen',
    model: 'Golf',
    color: 'negro',
    plate: '5678 HJP',
    address: 'Calle Fray Ceferino, Oviedo',
    latitude: 43.3612,
    longitude: -5.8502,
    phone: '600456789',
    allow_phone_calls: true,
    price: 5,
    available_in_minutes: 10,
  },
  demo_3: {
    id: 'demo_3',
    user_name: 'Nerea',
    user_photo: 'https://randomuser.me/api/portraits/women/68.jpg',
    user_id: 'seller-3',
    user_email: 'seller3@test.com',
    brand: 'Toyota',
    model: 'RAV4',
    color: 'azul',
    plate: '9012 LSR',
    address: 'Calle Campoamor, Oviedo',
    latitude: 43.363,
    longitude: -5.8489,
    phone: '600789012',
    allow_phone_calls: true,
    price: 7,
    available_in_minutes: 14,
  },
  demo_4: {
    id: 'demo_4',
    user_name: 'David',
    user_photo: 'https://randomuser.me/api/portraits/men/19.jpg',
    user_id: 'seller-4',
    user_email: 'seller4@test.com',
    brand: 'Renault',
    model: 'Trafic',
    color: 'gris',
    plate: '3456 JTZ',
    address: 'Plaza de la Escandalera, Oviedo',
    latitude: 43.3609,
    longitude: -5.8501,
    phone: '600234567',
    allow_phone_calls: true,
    price: 4,
    available_in_minutes: 4,
  },
  demo_5: {
    id: 'demo_5',
    user_name: 'Lucía',
    user_photo: 'https://randomuser.me/api/portraits/women/12.jpg',
    user_id: 'seller-5',
    user_email: 'seller5@test.com',
    brand: 'Peugeot',
    model: '208',
    color: 'rojo',
    plate: '7788 MNB',
    address: 'Calle Rosal, Oviedo',
    latitude: 43.3623,
    longitude: -5.8483,
    phone: '600345678',
    allow_phone_calls: true,
    price: 2,
    available_in_minutes: 3,
  },
  demo_6: {
    id: 'demo_6',
    user_name: 'Álvaro',
    user_photo: 'https://randomuser.me/api/portraits/men/61.jpg',
    user_id: 'seller-6',
    user_email: 'seller6@test.com',
    brand: 'Kia',
    model: 'Sportage',
    color: 'verde',
    plate: '2468 GHT',
    address: 'Calle Jovellanos, Oviedo',
    latitude: 43.3615,
    longitude: -5.8505,
    phone: '600567890',
    allow_phone_calls: true,
    price: 6,
    available_in_minutes: 18,
  },
};

export default function Navigate() {
  const alertId = getAlertIdFromLocation();

  const [user, setUser] = useState(null);
  const { location: engineLocation } = useLocationEngine();
  const [userLocation, setUserLocation] = useState([43.367, -5.844]);
  const [sellerLocation, setSellerLocation] = useState([43.362, -5.849]);
  const [isTracking, setIsTracking] = useState(false);

  useEffect(() => {
    if (!isTracking && engineLocation && engineLocation.length >= 2) {
      setUserLocation(engineLocation);
    }
  }, [engineLocation, isTracking]);
  const [paymentReleased, setPaymentReleased] = useState(false);
  const [showPaymentSuccess, setShowPaymentSuccess] = useState(false);
  const [forceRelease, setForceRelease] = useState(false);
  const [showAbandonWarning, setShowAbandonWarning] = useState(false);
  const [panelCollapsed, setPanelCollapsed] = useState(false);
  const [showCancelWarning, setShowCancelWarning] = useState(false);
  const _watchIdRef = useRef(null);
  const queryClient = useQueryClient();
  const hasReleasedPaymentRef = useRef(false);
  const animationRef = useRef(null);
  const wasWithin5mRef = useRef(false);
  const [routeDistanceKm, setRouteDistanceKm] = useState(null);
  const [routeDurationSec, setRouteDurationSec] = useState(null);
  const onRouteLoaded = useCallback(({ distanceKm, durationSec }) => {
    setRouteDistanceKm(distanceKm);
    setRouteDurationSec(durationSec);
  }, []);

  const authUser = useAuth().user;
  useEffect(() => {
    if (authUser) setUser(authUser);
  }, [authUser]);

  const [alert, setAlert] = useState(null);

  useEffect(() => {
    if (DEMO_ALERTS[alertId]) {
      setAlert(DEMO_ALERTS[alertId]);
      return;
    }
    const fetchAlert = async () => {
      try {
        const { data } = await alerts.getAlert(alertId);
        if (data) setAlert(data);
      } catch (err) {
        console.error('Error fetching alert:', err);
      }
    };
    if (alertId) fetchAlert();
  }, [alertId]);

  // Modo browse: 20 coches mock cuando no hay alertId. Usuario más cercano por defecto.
  const browseAlerts = useMemo(() => getMockNavigateCars(userLocation), [userLocation]);
  const nearestBrowseAlert = useMemo(() => {
    if (browseAlerts.length === 0) return null;
    const [uLat, uLng] = Array.isArray(userLocation)
      ? userLocation
      : [userLocation?.lat, userLocation?.lng];
    if (uLat == null || uLng == null) return browseAlerts[0];
    const sorted = [...browseAlerts].sort((a, b) => {
      const da = haversineKm(uLat, uLng, a.latitude ?? a.lat, a.longitude ?? a.lng);
      const db = haversineKm(uLat, uLng, b.latitude ?? b.lat, b.longitude ?? b.lng);
      return da - db;
    });
    return sorted[0];
  }, [browseAlerts, userLocation]);

  const startTracking = () => {
    setIsTracking(true);
    try {
      window.localStorage.setItem('showBanner', 'true');
      window.dispatchEvent(new Event('waitme:requestsChanged'));
      window.dispatchEvent(new Event('waitme:showIncomingBanner'));
    } catch {}

    const moveTowardsDestination = () => {
      setUserLocation((prevLoc) => {
        if (!prevLoc || !sellerLocation) return prevLoc;
        const lat1 = prevLoc[0],
          lon1 = prevLoc[1];
        const lat2 = sellerLocation[0],
          lon2 = sellerLocation[1];
        const R = 6371000;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) ** 2;
        const distM = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        if (distM < 5) return prevLoc;
        const stepSize = 15 / R;
        const fraction = Math.min(stepSize / (distM / R), 1);
        return [lat1 + (lat2 - lat1) * fraction, lon1 + (lon2 - lon1) * fraction];
      });

      // Mover al vendedor también hacia el usuario
      setSellerLocation((prevLoc) => {
        if (!prevLoc || !userLocation) return prevLoc;
        const lat1 = prevLoc[0],
          lon1 = prevLoc[1];
        const lat2 = userLocation[0],
          lon2 = userLocation[1];
        const R = 6371000;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) ** 2;
        const distM = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        if (distM < 5) return prevLoc;
        const stepSize = 12 / R;
        const fraction = Math.min(stepSize / (distM / R), 1);
        return [lat1 + (lat2 - lat1) * fraction, lon1 + (lon2 - lon1) * fraction];
      });
    };
    animationRef.current = setInterval(moveTowardsDestination, 400);
  };

  const stopTracking = () => {
    if (animationRef.current) {
      clearInterval(animationRef.current);
      animationRef.current = null;
    }
    setIsTracking(false);
  };

  useEffect(() => {
    return () => {
      if (animationRef.current) clearInterval(animationRef.current);
    };
  }, []);

  useEffect(() => {
    if (alert?.latitude != null && alert?.longitude != null) {
      setSellerLocation([Number(alert.latitude), Number(alert.longitude)]);
    } else if (alert && (sellerLocation == null || sellerLocation.length < 2)) {
      setSellerLocation([43.362, -5.849]);
    }
  }, [alert]);

  const calculateDistanceBetweenUsers = () => {
    if (!userLocation || !sellerLocation) return null;
    const m = getMetersBetween(userLocation, sellerLocation);
    return Number.isFinite(m) ? m : null;
  };

  const distanceMeters = calculateDistanceBetweenUsers();

  useEffect(() => {
    const sellerHere =
      alert &&
      user &&
      (String(alert.user_id) === String(user?.id) ||
        String(alert.user_email) === String(user?.email));
    if (!alert || sellerHere || paymentReleased) return;
    if (distanceMeters === null) return;
    if (distanceMeters <= 5) {
      wasWithin5mRef.current = true;
      setShowAbandonWarning(false);
    } else if (wasWithin5mRef.current) setShowAbandonWarning(true);
  }, [distanceMeters, alert, user, paymentReleased]);

  const distLabel =
    distanceMeters != null
      ? distanceMeters < 1000
        ? `${Math.round(distanceMeters)} m`
        : `${(distanceMeters / 1000).toFixed(1)} km`
      : '--';

  const etaMinutes = (() => {
    if (
      distanceMeters == null ||
      distanceMeters <= 0 ||
      !routeDistanceKm ||
      routeDistanceKm <= 0 ||
      !routeDurationSec
    )
      return null;
    const remainingKm = distanceMeters / 1000;
    const speedKmPerSec = routeDistanceKm / routeDurationSec;
    if (!speedKmPerSec) return null;
    return Math.max(1, Math.round(remainingKm / speedKmPerSec / 60));
  })();

  const doReleasePayment = useCallback(
    async (a, u) => {
      if (!a || !u || hasReleasedPaymentRef.current) return;
      hasReleasedPaymentRef.current = true;
      const amount = Number(a?.price ?? 0);
      const sellerId = a?.user_id ?? a?.user_email;
      const buyerId = u?.id;
      if (Number.isFinite(amount) && sellerId && buyerId) {
        finalize({ outcome: OUTCOME.FINALIZADA_OK, amount, sellerId, buyerId });
      }
      const isDemo = String(a.id).startsWith('demo_');
      if (!isDemo) {
        await alerts.updateAlert(a.id, { status: 'completed' });
        const sellerEarnings = a.price * 0.67;
        const platformFee = a.price * 0.33;
        const { error: txErr } = await transactions.createTransaction({
          alert_id: a.id,
          seller_id: a.user_id ?? a.seller_id,
          buyer_id: u.id,
          seller_name: a.user_name ?? 'Usuario',
          buyer_name: u.full_name?.split(' ')[0] || 'Usuario',
          amount: a.price,
          seller_earnings: sellerEarnings,
          platform_fee: platformFee,
          status: 'completed',
          address: a.address ?? a.address_text,
        });
        if (txErr) console.error('Error creando transacción:', txErr);
        const { data: conv } = await chat.createConversation({
          buyerId: u.id,
          sellerId: a.user_id || a.seller_id,
          alertId: a.id,
        });
        if (conv?.id) {
          await chat.sendMessage({
            conversationId: conv.id,
            senderId: u.id,
            body: `✅ Pago liberado: ${a.price.toFixed(2)}€. El vendedor recibirá ${sellerEarnings.toFixed(2)}€`,
          });
        }
      }
      setPaymentReleased(true);
      setShowPaymentSuccess(true);
      try {
        window.dispatchEvent(
          new CustomEvent('waitme:paymentReleased', {
            detail: { amount: Number(a?.price ?? 0) },
          })
        );
      } catch {}
      queryClient.invalidateQueries({ queryKey: ['myAlerts'] });
      queryClient.invalidateQueries({ queryKey: ['navigationAlert'] });
      queryClient.invalidateQueries({ queryKey: ['myTransactions'] });
      setTimeout(() => {
        window.location.href = createPageUrl('History');
      }, 3000);
    },
    [queryClient]
  );

  const isSellerHere =
    alert &&
    user &&
    (String(alert.user_id) === String(user?.id) ||
      String(alert.user_email) === String(user?.email));

  useTransactionMonitoring({
    enabled: !!(alert && user && !isSellerHere && !paymentReleased && !forceRelease),
    getUserALocation: () =>
      sellerLocation && sellerLocation.length >= 2
        ? { lat: sellerLocation[0], lng: sellerLocation[1] }
        : null,
    getUserBLocation: () =>
      userLocation && userLocation.length >= 2
        ? { lat: userLocation[0], lng: userLocation[1] }
        : null,
    getAlertLocation: () =>
      alert?.latitude != null && alert?.longitude != null
        ? { lat: alert.latitude, lng: alert.longitude }
        : null,
    onCompleted: () => doReleasePayment(alert, user),
  });

  useEffect(() => {
    if (!forceRelease || !alert || !user || hasReleasedPaymentRef.current || paymentReleased)
      return;
    if (isSellerHere) return;
    setForceRelease(false);
    doReleasePayment(alert, user);
  }, [forceRelease, alert, user, paymentReleased, isSellerHere, doReleasePayment]);

  const displayAlert = alert;
  const isBrowseMode = !alertId && !alert;
  const displayAlertOrNearest = displayAlert || (isBrowseMode ? nearestBrowseAlert : null);
  const isSeller =
    displayAlert &&
    user &&
    (String(displayAlert.user_id) === String(user?.id) ||
      String(displayAlert.user_email) === String(user?.email));
  const isBuyer =
    displayAlert &&
    user &&
    (String(displayAlert.reserved_by_id) === String(user?.id) ||
      String(displayAlert.reserved_by_email) === String(user?.email));

  const sellerName =
    (isBrowseMode
      ? displayAlertOrNearest?.user_name
      : isBuyer
        ? displayAlert?.user_name
        : displayAlert?.reserved_by_name || displayAlert?.user_name || 'Usuario'
    )?.split(' ')[0] || 'Usuario';
  const sellerPhoto = isBrowseMode
    ? displayAlertOrNearest?.user_photo || null
    : isBuyer
      ? displayAlert?.user_photo || null
      : displayAlert?.reserved_by_photo ||
        (displayAlert?.reserved_by_name
          ? `https://ui-avatars.com/api/?name=${encodeURIComponent(displayAlert.reserved_by_name)}&background=7c3aed&color=fff&size=128`
          : null);

  // Icono del usuario: mi foto cuadrada con bordes redondeados (parpadeante verde) + icono coche
  const userCarIcon = displayAlert?.color
    ? `<svg width="20" height="12" viewBox="0 0 48 24" style="position:absolute;bottom:-4px;right:-4px;" fill="none">
        <path d="M8 16 L10 10 L16 8 L32 8 L38 10 L42 14 L42 18 L8 18 Z" fill="${getCarFill(displayAlert.color)}" stroke="white" stroke-width="1.5"/>
        <path d="M16 9 L18 12 L30 12 L32 9 Z" fill="rgba(255,255,255,0.3)" stroke="white" stroke-width="0.5"/>
        <circle cx="14" cy="18" r="4" fill="#333" stroke="white" stroke-width="1"/>
        <circle cx="14" cy="18" r="2" fill="#666"/>
        <circle cx="36" cy="18" r="4" fill="#333" stroke="white" stroke-width="1"/>
        <circle cx="36" cy="18" r="2" fill="#666"/>
       </svg>`
    : '';

  const userMapIcon = user?.photo_url
    ? `<div style="position:relative;width:44px;height:44px;border-radius:10px;overflow:visible;border:3px solid #22c55e;box-shadow:0 0 14px rgba(34,197,94,0.9);animation:pulse-green 1.2s ease-in-out infinite;">
        <img src="${user.photo_url}" style="width:100%;height:100%;object-fit:cover;" />
        ${userCarIcon}
       </div>
       <style>@keyframes pulse-green{0%,100%{box-shadow:0 0 10px rgba(34,197,94,0.9);}50%{box-shadow:0 0 22px rgba(34,197,94,1);}}</style>`
    : `<div style="position:relative;width:44px;height:44px;border-radius:10px;border:3px solid #22c55e;box-shadow:0 0 14px rgba(34,197,94,0.9);background:#1a1a2e;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:bold;color:#22c55e;">Yo${userCarIcon}</div>`;

  // Icono del vendedor: foto cuadrada con bordes redondeados + icono coche
  const sellerCarIcon = (displayAlertOrNearest || displayAlert)?.color
    ? `<svg width="20" height="12" viewBox="0 0 48 24" style="position:absolute;bottom:-4px;right:-4px;" fill="none">
        <path d="M8 16 L10 10 L16 8 L32 8 L38 10 L42 14 L42 18 L8 18 Z" fill="${getCarFill((displayAlertOrNearest || displayAlert)?.color)}" stroke="white" stroke-width="1.5"/>
        <path d="M16 9 L18 12 L30 12 L32 9 Z" fill="rgba(255,255,255,0.3)" stroke="white" stroke-width="0.5"/>
        <circle cx="14" cy="18" r="4" fill="#333" stroke="white" stroke-width="1"/>
        <circle cx="14" cy="18" r="2" fill="#666"/>
        <circle cx="36" cy="18" r="4" fill="#333" stroke="white" stroke-width="1"/>
        <circle cx="36" cy="18" r="2" fill="#666"/>
       </svg>`
    : '';

  const sellerMapIcon = sellerPhoto
    ? `<div style="position:relative;width:44px;height:44px;border-radius:10px;overflow:visible;border:3px solid #a855f7;box-shadow:0 0 12px rgba(168,85,247,0.8);">
        <img src="${sellerPhoto}" style="width:100%;height:100%;object-fit:cover;border-radius:8px;" />
        ${sellerCarIcon}
       </div>`
    : `<div style="position:relative;width:44px;height:44px;border-radius:10px;border:3px solid #a855f7;box-shadow:0 0 12px rgba(168,85,247,0.8);background:#1a1a2e;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:bold;color:#a855f7;">${sellerName.charAt(0)}${sellerCarIcon}</div>`;

  // Construir alert en formato compatible con UserAlertCard
  const alertForCard = displayAlertOrNearest
    ? {
        ...displayAlertOrNearest,
        user_name: sellerName,
        user_photo: sellerPhoto,
        brand: isBrowseMode
          ? displayAlertOrNearest.brand
          : isBuyer
            ? displayAlert.brand
            : displayAlert.reserved_by_car?.split(' ')[0] || '',
        model: isBrowseMode
          ? displayAlertOrNearest.model
          : isBuyer
            ? displayAlert.model
            : displayAlert.reserved_by_car?.split(' ').slice(1).join(' ') || '',
        plate: isBrowseMode
          ? displayAlertOrNearest.plate
          : isBuyer
            ? displayAlert.plate
            : displayAlert.reserved_by_plate || '',
        color: isBrowseMode
          ? displayAlertOrNearest.color
          : isBuyer
            ? displayAlert.color
            : displayAlert.reserved_by_car_color || 'gris',
        phone: isBrowseMode ? null : isBuyer ? displayAlert.phone || null : null,
        allow_phone_calls: isBrowseMode ? false : isBuyer ? displayAlert.allow_phone_calls : false,
        wait_until: displayAlertOrNearest.expires_at || displayAlertOrNearest.wait_until,
      }
    : null;

  return (
    <div className="min-h-[100dvh] bg-black text-white flex flex-col">
      {/* Payment success overlay */}
      {showPaymentSuccess && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-[200] flex items-center justify-center bg-black/85 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-gradient-to-br from-green-500 to-green-600 rounded-3xl p-8 mx-6 text-center shadow-2xl"
          >
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-5xl">✅</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">¡Pago liberado!</h2>
            <p className="text-green-100 mb-4">Estás a menos de 5 metros</p>
            <div className="bg-white/20 rounded-xl p-3">
              <p className="text-white font-bold text-2xl">
                {alert?.price != null ? Number(alert.price).toFixed(2) : '0.00'}€
              </p>
              <p className="text-green-100 text-sm">Transacción completada</p>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Abandon warning */}
      {showAbandonWarning && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-[150] flex items-center justify-center bg-black/80 p-4"
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="bg-amber-500/20 border-2 border-amber-500 rounded-2xl p-6 max-w-sm text-center"
          >
            <p className="text-amber-400 font-bold text-lg">Estás abandonando el lugar...</p>
            <p className="text-gray-300 text-sm mt-2">
              Vuelve a menos de 5 m para completar la entrega.
            </p>
            <Button
              className="mt-4 bg-amber-600 hover:bg-amber-700 text-white"
              onClick={() => setShowAbandonWarning(false)}
            >
              Entendido
            </Button>
          </motion.div>
        </motion.div>
      )}

      {/* Cancel warning (reserved alert) */}
      {showCancelWarning && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-[150] bg-black/70"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-[150] flex items-end"
          >
            <div className="w-full bg-gray-950 rounded-t-3xl shadow-2xl border-t border-gray-800 border-b-2 border-b-purple-500">
              {/* Close button */}
              <button
                onClick={() => setShowCancelWarning(false)}
                className="absolute top-4 right-4 w-7 h-7 rounded-md bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400 hover:bg-red-500/30 transition-colors z-10"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="p-6 pt-8 flex flex-col gap-4">
                {/* Header */}
                <div className="flex justify-center">
                  <div className="px-4 py-2 rounded-lg bg-red-700/40 border border-red-500/60">
                    <span className="text-white font-semibold text-sm">⚠️ ATENCIÓN</span>
                  </div>
                </div>

                {/* Message */}
                <div className="text-center">
                  <p className="text-white font-bold text-base">La alerta está reservada.</p>
                  <p className="text-gray-400 text-sm mt-1">
                    {sellerName} está en camino. Si la cancelas, perderás la reserva.
                  </p>
                </div>

                {/* Buttons */}
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <Button
                    onClick={() => setShowCancelWarning(false)}
                    className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg h-9"
                  >
                    Volver
                  </Button>
                  <Button
                    onClick={async () => {
                      await alerts.updateAlert(displayAlert.id, {
                        status: 'cancelled',
                        cancel_reason: 'user_cancelled',
                      });
                      setShowCancelWarning(false);
                      setTimeout(() => {
                        window.location.href = createPageUrl('Home');
                      }, 500);
                    }}
                    className="bg-red-600 hover:bg-red-700 text-white rounded-lg h-9"
                  >
                    Me voy
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* MAPA: browse = 20 coches estáticos; con alerta = ruta y marcadores */}
      <div className="fixed left-0 right-0 z-0" style={{ top: '56px', bottom: '0' }}>
        <ParkingMap
          alerts={isBrowseMode ? browseAlerts : []}
          userLocation={userLocation}
          selectedAlert={displayAlertOrNearest}
          showRoute={!isBrowseMode && !!displayAlert}
          sellerLocation={sellerLocation?.length >= 2 ? sellerLocation : [43.362, -5.849]}
          zoomControl={false}
          className="h-full w-full"
          userAsCar={false}
          showSellerMarker={!isBrowseMode}
          onRouteLoaded={onRouteLoaded}
          userPhotoHtml={userMapIcon}
          sellerPhotoHtml={sellerMapIcon}
        />
      </div>

      {/* Botones flotantes: Distancia y ETA — solo cuando navegando a alerta */}
      {!isBrowseMode && (
        <div
          className="fixed left-0 right-0 z-40 px-4 flex gap-2"
          style={{ top: 'calc(56px + 15px)' }}
        >
          <div className="flex-1 bg-gray-900/50 backdrop-blur-md rounded-2xl px-3 py-2 flex items-center gap-2 shadow-xl border border-gray-700/30">
            <Navigation className="w-4 h-4 text-blue-400 flex-shrink-0" />
            <div>
              <p className="text-white font-black text-base leading-none">{distLabel}</p>
              <p className="text-gray-400 text-[10px] mt-0.5">Distancia</p>
            </div>
          </div>
          <div className="flex-1 bg-gray-900/50 backdrop-blur-md rounded-2xl px-3 py-2 flex items-center gap-2 shadow-xl border border-gray-700/30">
            <Clock className="w-4 h-4 text-green-400 flex-shrink-0" />
            <div>
              <p className="text-white font-black text-base leading-none">
                {etaMinutes != null ? `${etaMinutes} min` : '--'}
              </p>
              <p className="text-gray-400 text-[10px] mt-0.5">Tiempo estimado</p>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM PANEL */}
      <div className="fixed left-0 right-0 z-50" style={{ bottom: 'var(--bottom-nav-h)' }}>
        <div className="bg-gray-950 rounded-t-3xl shadow-2xl border-t border-gray-800">
          {/* Toggle button: flecha abajo/arriba */}
          <button
            onClick={() => setPanelCollapsed((c) => !c)}
            className="w-full flex items-center justify-center py-2 focus:outline-none"
          >
            {panelCollapsed ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </button>

          <AnimatePresence initial={false}>
            {panelCollapsed ? (
              /* Panel colapsado: solo foto cuadrada + nombre */
              <motion.div
                key="collapsed"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="flex items-center gap-3 px-4 pb-3"
              >
                <div className="w-10 h-10 rounded-[6px] overflow-hidden border-2 border-purple-500/50 flex-shrink-0">
                  {sellerPhoto ? (
                    <img
                      src={sellerPhoto}
                      alt={sellerName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-lg font-bold text-purple-400">
                      {sellerName.charAt(0)}
                    </div>
                  )}
                </div>
                <p className="font-bold text-white">{sellerName}</p>
              </motion.div>
            ) : (
              /* Panel expandido: UserAlertCard completa */
              <motion.div
                key="expanded"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="px-3 pb-3"
              >
                {alertForCard && (
                  <div className="relative">
                    {!isBrowseMode && isSeller && displayAlert?.status === 'reserved' && (
                      <button
                        onClick={() => setShowCancelWarning(true)}
                        className="absolute top-3 right-3 w-6 h-6 rounded-md bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400 hover:bg-red-500/30 transition-colors z-10"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                    <UserAlertCard
                      alert={alertForCard}
                      hideBuy={true}
                      userLocation={userLocation}
                      showDistanceInMeters={true}
                      buyLabel={isSeller ? 'He desaparcado ✓' : !isTracking ? '▶ IR' : 'Detener'}
                      onBuyAlert={() => {
                        if (isSeller) {
                          window.location.href = createPageUrl('History');
                        } else if (!isTracking) {
                          startTracking();
                        } else {
                          stopTracking();
                        }
                      }}
                      onChat={() => {
                        window.location.href = createPageUrl(
                          `Chat?alertId=${alertId}&userId=${displayAlert?.user_email || displayAlert?.user_id}`
                        );
                      }}
                      onCall={() => {
                        const phone = isBuyer ? displayAlert?.phone : null;
                        if (phone) window.location.href = `tel:${phone}`;
                      }}
                    />
                    {isBrowseMode && (
                      <a
                        href={createPageUrl('/')}
                        className="block w-full mt-3 py-2.5 rounded-xl bg-purple-600/50 border border-purple-500/50 text-center text-sm font-semibold text-purple-200 hover:bg-purple-600/70 transition-colors"
                      >
                        Ir a Mapa para reservar
                      </a>
                    )}
                  </div>
                )}
                {!isSeller &&
                  displayAlert &&
                  String(displayAlert.id).startsWith('demo_') &&
                  !paymentReleased && (
                    <button
                      onClick={() => setForceRelease(true)}
                      className="w-full mt-2 h-7 rounded-xl border border-dashed border-amber-500/50 text-amber-400 text-xs hover:bg-amber-500/10 transition-colors"
                    >
                      Simular llegada (demo)
                    </button>
                  )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
