import { useCallback, useEffect, useMemo, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';
import { getVisibleActiveSellerAlerts, readHiddenKeys } from '@/lib/alertSelectors';
import { useMyAlerts } from '@/hooks/useMyAlerts';

const BASE_BTN =
  'flex-1 flex flex-col items-center justify-center text-purple-400 ' + 'h-[60px] rounded-lg mx-1';
const ACTIVE_STYLE = 'bg-purple-700/30 border border-purple-500/50';
const LABEL_CLASS = 'text-[10px] font-bold leading-none mt-[2px] whitespace-nowrap';
const _LABEL_CLASS_LONG =
  'text-[9px] font-bold leading-none mt-[2px] whitespace-nowrap tracking-tight';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [chatUnread, setChatUnread] = useState(0);

  // Escuchar evento cuando llega un waitme aceptado o mensaje nuevo
  useEffect(() => {
    const handler = () => {
      try {
        const count = parseInt(localStorage.getItem('waitme:chat_unread') || '0', 10);
        setChatUnread(isNaN(count) ? 0 : count);
      } catch (error) {
        console.error('[WaitMe Error]', error);
      }
    };
    handler(); // cargar inicial
    window.addEventListener('waitme:chatUnreadUpdate', handler);
    window.addEventListener('waitme:acceptedWaitMe', handler);
    return () => {
      window.removeEventListener('waitme:chatUnreadUpdate', handler);
      window.removeEventListener('waitme:acceptedWaitMe', handler);
    };
  }, []);

  // Una sola fuente de verdad: myAlerts (el badge se deriva de aquí)
  const { data: myAlerts = [], isFetched } = useMyAlerts();

  // activeCount = exact number of visible seller alerts in "Tus alertas → Activas".
  // Same selector as HistorySellerView so badge and list are always in sync.
  // Falls back to 0 until data is fetched (no ghost badge).
  const activeCount = useMemo(() => {
    if (!isFetched) return 0;
    const hiddenKeys = readHiddenKeys();
    return getVisibleActiveSellerAlerts(myAlerts, user?.id, user?.email, hiddenKeys).length;
  }, [isFetched, myAlerts, user?.id, user?.email]);

  // Refresco inmediato (cuando se crea/cancela/expira una alerta)
  useEffect(() => {
    const handler = () => {
      queryClient.invalidateQueries({ queryKey: ['myAlerts'], refetchType: 'none' });
    };
    window.addEventListener('waitme:badgeRefresh', handler);
    return () => window.removeEventListener('waitme:badgeRefresh', handler);
  }, [queryClient]);

  const handleChatsClick = useCallback(() => {
    try {
      localStorage.setItem('waitme:chat_unread', '0');
      setChatUnread(0);
    } catch (error) {
      console.error('[WaitMe Error]', error);
    }
  }, []);

  const divider = <div className="w-px h-8 bg-gray-700" />;

  const isMapActive = location.pathname === '/';

  const handleMapClick = useCallback(
    (e) => {
      e?.preventDefault?.();
      try {
        window.dispatchEvent(new Event('waitme:goLogo'));
      } catch (error) {
        console.error('[WaitMe Error]', error);
      }
      navigate('/', { replace: false });
    },
    [navigate]
  );

  return (
    <nav
      data-waitme-nav
      className="fixed bottom-0 left-0 right-0 px-4 pt-[6px] z-[2147483647] pointer-events-auto"
      style={{
        backgroundColor: '#0B0B0F',
        borderTop: '1px solid rgba(255,255,255,0.05)',
        paddingBottom: 'calc(4px + env(safe-area-inset-bottom, 0px))',
        paddingLeft: 'max(1rem, env(safe-area-inset-left, 0px))',
        paddingRight: 'max(1rem, env(safe-area-inset-right, 0px))',
      }}
    >
      <div className="flex items-center max-w-md mx-auto pointer-events-auto">
        <NavLink
          to="/history"
          className={({ isActive }) => `${BASE_BTN} ${isActive ? ACTIVE_STYLE : ''}`}
          onClick={(e) => {
            e.preventDefault();
            navigate('/history');
          }}
        >
          <div className="relative">
            {activeCount > 0 && (
              <span
                // Ajuste fino: +4px derecha (número más centrado)
                className="absolute left-[-16px] top-[4px] w-5 h-5 rounded-full bg-green-500/25 border border-green-500/40 flex items-center justify-center text-[11px] font-extrabold text-green-200 shadow-md"
              >
                {activeCount > 9 ? '9+' : activeCount}
              </span>
            )}
            <svg
              className="w-10 h-10 drop-shadow-[0_0_1px_rgba(255,255,255,0.85)]"
              viewBox="0 0 32 32"
              fill="none"
            >
              <path d="M30 8 L14 8 L14 5 L8 10 L14 15 L14 12 L30 12 Z" fill="currentColor" />
              <path d="M2 20 L18 20 L18 17 L24 22 L18 27 L18 24 L2 24 Z" fill="currentColor" />
            </svg>
          </div>
          <span className={LABEL_CLASS}>Alertas</span>
        </NavLink>

        {divider}

        {/* MAPA: no usar NavLink aquí, porque si ya estás en "/" no fuerza el reset del Home */}
        <a
          href="/"
          onClick={handleMapClick}
          className={`${BASE_BTN} ${isMapActive ? ACTIVE_STYLE : ''}`}
        >
          <svg
            className="w-10 h-10 drop-shadow-[0_0_1px_rgba(255,255,255,0.85)]"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"
            />
          </svg>
          <span className={LABEL_CLASS}>Mapa</span>
        </a>

        {divider}

        <NavLink
          to="/chats"
          className={({ isActive }) => `${BASE_BTN} ${isActive ? ACTIVE_STYLE : ''}`}
          onClick={(e) => {
            e.preventDefault();
            handleChatsClick();
            navigate('/chats');
          }}
        >
          <div className="relative">
            {chatUnread > 0 && (
              <span className="absolute -top-1.5 -right-2.5 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center text-[10px] font-black text-white z-10 border border-red-400 shadow-lg shadow-red-500/40">
                {chatUnread > 9 ? '9+' : chatUnread}
              </span>
            )}
            <MessageCircle className="w-10 h-10 drop-shadow-[0_0_1px_rgba(255,255,255,0.85)]" />
          </div>
          <span className={LABEL_CLASS}>Chats</span>
        </NavLink>
      </div>
    </nav>
  );
}
